package binary_Search_Tree.services;

public class Node {
	public int nodeData;
	public Node left, right;

	public Node(int data) {

		nodeData = data;
		left = null;
		right = null;

	}

}
